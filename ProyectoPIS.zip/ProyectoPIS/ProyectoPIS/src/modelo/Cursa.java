/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


public class Cursa {
    private Integer id;
    private String nombre_curso;
    private String horario_curso;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre_curso() {
        return nombre_curso;
    }

    public void setNombre_curso(String nombre_curso) {
        this.nombre_curso = nombre_curso;
    }

    public String getHorario_curso() {
        return horario_curso;
    }

    public void setHorario_curso(String horario_curso) {
        this.horario_curso = horario_curso;
    }
    
    
    
}
